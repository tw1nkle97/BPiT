<?php
/* greet.php
 * Получает данные с preview.php и выводит персональное приветствие.
 */
function e($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$fio = $_POST['fio'] ?? 'Соискатель';
$position = $_POST['position'] ?? 'выбранная позиция';
$email = $_POST['email'] ?? '';
$experience = $_POST['experience'] ?? '0';
$skillsStr = $_POST['skills'] ?? '';
$form_id = $_POST['form_id'] ?? '';
$source = $_POST['source'] ?? '';
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Приветствие</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f8fb;
            padding: 20px
        }

        .card {
            max-width: 720px;
            margin: auto;
            background: #fff;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .08);
        }

        .muted {
            color: #64748b
        }

        .pill {
            display: inline-block;
            background: #eef2ff;
            color: #3730a3;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 12px;
            margin-right: 6px
        }
    </style>
</head>

<body>
    <div class="card">
        <h1>Здравствуйте, <?= e($fio) ?>!</h1>
        <p>Спасибо за интерес к вакансии <strong><?= e($position) ?></strong>. Мы получили ваши данные и свяжемся с вами
            по адресу <strong><?= e($email ?: '—') ?></strong>.</p>
        <p>Указанный опыт: <strong><?= e($experience) ?></strong> лет.</p>

        <?php if ($skillsStr): ?>
            <p>Ваши ключевые навыки:</p>
            <p>
                <?php foreach (explode(',', $skillsStr) as $sk): ?>
                    <span class="pill"><?= e(trim($sk)) ?></span>
                <?php endforeach; ?>
            </p>
        <?php endif; ?>

        <p class="muted">Form: <?= e($form_id) ?> | Source: <?= e($source) ?></p>

        <p><a href="index.php">Заполнить новую анкету</a></p>
    </div>
</body>

</html>