<?php
/* ------------------------------------------------------------
 * ЕДИНЫЙ ФАЙЛ: lab_all_in_one.php
 * Задание 1 — Переменные всех типов + присваивание по ссылке
 * Задание 2 — Арифметика + условный оператор
 * Задание 3 — Циклы while / do..while / foreach / for
 * Задание 4 — Чётные трёхзначные, кратные заданному числу
 * ------------------------------------------------------------ */

function gcd($a, $b){
    $a = abs($a); 
    $b = abs($b);
    while ($b != 0){ 
        $t = $a % $b; 
        $a = $b; 
        $b = $t; 
    }
    return $a;
}

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Задания 1–4 — формы и PHP</title>
<style>
  body{font-family:Arial, sans-serif;background:#f7f9fc;margin:0}
  .wrap{max-width:980px;margin:auto;padding:24px}
  h2{margin:24px 0 8px}
  form{background:#fff;padding:16px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);margin-bottom:18px}
  fieldset{border:1px solid #e5e7eb;border-radius:8px;margin:12px 0;padding:12px}
  legend{color:#374151}
  label{display:block;margin:8px 0 4px}
  .row{display:flex;gap:12px;flex-wrap:wrap}
  .row > div{flex:1 1 220px}
  input[type=text],input[type=number],input[type=email],input[type=tel],select,textarea{
    width:100%;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;box-sizing:border-box}
  .actions{display:flex;gap:10px;margin-top:10px}
  .btn{padding:9px 14px;border:0;border-radius:10px;cursor:pointer}
  .btn-primary{background:#2563eb;color:#fff}
  .btn-ghost{background:#e5e7eb}
  .card{background:#fff;padding:14px;border-radius:10px;border:1px solid #e5e7eb;margin-top:10px}
  code, pre{background:#0b1020;color:#e6edf3;border-radius:8px;padding:10px;display:block;overflow:auto}
  .muted{color:#6b7280}
  hr{border:none;border-top:1px solid #e5e7eb;margin:24px 0}
  ul.inline{padding-left:18px}
</style>
</head>
<body>
<div class="wrap">
  <h1>Практика PHP — формы и обработка (Задания 1–4)</h1>
  <p class="muted">Все задания выполнены в одном файле. Заполняйте формы ниже — результаты появятся сразу под каждой формой.</p>

  <!-- ========================= ЗАДАНИЕ 1 ========================= -->
  <h2 id="t1">Задание 1. Переменные всех типов + присваивание по ссылке</h2>
  <form method="post">
    <input type="hidden" name="task" value="1">
    <fieldset>
      <legend>Исходные значения переменных</legend>
      <div class="row">
        <div>
          <label>Целое (int) — $intVal</label>
          <input type="number" name="intVal" value="<?= isset($_POST['intVal']) ? e($_POST['intVal']) : 5 ?>">
        </div>
        <div>
          <label>Вещественное (float) — $floatVal</label>
          <input type="text" name="floatVal" value="<?= isset($_POST['floatVal']) ? e($_POST['floatVal']) : '3.14' ?>">
        </div>
        <div>
          <label>Строка (string) — $strVal</label>
          <input type="text" name="strVal" value="<?= isset($_POST['strVal']) ? e($_POST['strVal']) : 'Hello PHP' ?>">
        </div>
      </div>
      <div class="row">
        <div>
          <label>Логическое (bool) — $boolVal</label>
          <select name="boolVal">
            <?php
              $bsel = isset($_POST['boolVal']) ? $_POST['boolVal'] : '1';
            ?>
            <option value="1" <?= $bsel==='1' ? 'selected' : '' ?>>true</option>
            <option value="0" <?= $bsel==='0' ? 'selected' : '' ?>>false</option>
          </select>
        </div>
        <div>
          <label>NULL (отметьте, чтобы $nullVal = null)</label>
          <?php $nsel = isset($_POST['nullVal']) ? 'checked' : ''; ?>
          <input type="checkbox" name="nullVal" value="1" <?= $nsel ?>> Установить null
        </div>
        <div>
          <label>Массив (array) — $arrVal (через запятую)</label>
          <input type="text" name="arrVal" value="<?= isset($_POST['arrVal']) ? e($_POST['arrVal']) : '1,2,3,PHP' ?>">
        </div>
      </div>
    </fieldset>

    <fieldset>
      <legend>Демонстрация "переменной переменных" и присваивания по ссылке</legend>
      <div class="row">
        <div>
          <label>Имя базовой переменной (например varName) — будет создана $varName</label>
          <input type="text" name="baseVarName" value="<?= isset($_POST['baseVarName']) ? e($_POST['baseVarName']) : 'var' ?>">
        </div>
        <div>
          <label>Значение для переменной переменных $$listName</label>
          <input type="text" name="varOfVarValue" value="<?= isset($_POST['varOfVarValue']) ? e($_POST['varOfVarValue']) : 'assigned via $$' ?>">
        </div>
        <div>
          <label>Имя переменной-указателя (ссылка) — $refName</label>
          <input type="text" name="refName" value="<?= isset($_POST['refName']) ? e($_POST['refName']) : 'ref' ?>">
        </div>
      </div>
    </fieldset>

    <div class="actions">
      <button class="btn btn-primary" type="submit">Показать результат</button>
      <button class="btn btn-ghost" type="reset">Сброс</button>
    </div>
  </form>

  <?php if (($_POST['task'] ?? '') === '1'): ?>
    <div class="card">
      <?php
      // --- Получаем и приводим значения ---
      $intVal   = isset($_POST['intVal']) ? (int)$_POST['intVal'] : 5;
      $floatVal = isset($_POST['floatVal']) ? (float)str_replace(',', '.', $_POST['floatVal']) : 3.14;
      $strVal   = isset($_POST['strVal']) ? (string)$_POST['strVal'] : 'Hello PHP';
      $boolVal  = isset($_POST['boolVal']) && $_POST['boolVal'] === '0' ? false : true;
      $nullVal  = isset($_POST['nullVal']) ? null : 'не null';
      $arrVal   = isset($_POST['arrVal']) && trim($_POST['arrVal']) !== '' ? array_map('trim', explode(',', $_POST['arrVal'])) : [1,2,3,'PHP'];

      $baseVarName   = $_POST['baseVarName'] ?? 'var';
      $varOfVarValue = $_POST['varOfVarValue'] ?? 'assigned via $$';
      $refName       = $_POST['refName'] ?? 'ref';

      // --- Переменная переменных ---
      // Создаём $list = $baseVarName; затем $$list = $varOfVarValue;
      $list = $baseVarName; // например 'var'
      $$list = $varOfVarValue; // создаст $var со значением $varOfVarValue

      // --- Присваивание по ссылке ---
      $varRefSource = 'test';     // источник
      ${$refName} = &$varRefSource; // $refName (например $ref) — это ССЫЛКА на $varRefSource
      ${$refName} = 'new value via reference'; // изменяем через ссылку — меняется и $varRefSource

      // Вывод:
      echo "<h3>Результаты</h3>";
      echo "<ul class='inline'>";
      echo "<li>\$intVal (int) = <strong>".e($intVal)."</strong></li>";
      echo "<li>\$floatVal (float) = <strong>".e($floatVal)."</strong></li>";
      echo "<li>\$strVal (string) = <strong>".e($strVal)."</strong></li>";
      echo "<li>\$boolVal (bool) = <strong>".($boolVal ? 'true' : 'false')."</strong></li>";
      echo "<li>\$nullVal = <strong>".(is_null($nullVal) ? 'NULL' : e($nullVal))."</strong></li>";
      echo "<li>\$arrVal (array) = <strong>".e(implode(', ', $arrVal))."</strong></li>";
      echo "</ul>";

      echo "<p><strong>Переменная переменных:</strong> \$list = '".e($list)."', создана \$".e($list)." = <em>".e($$list)."</em></p>";
      echo "<p><strong>Присваивание по ссылке:</strong> \$varRefSource теперь = <em>".e($varRefSource)."</em> (изменено через \$".e($refName).")</p>";
      ?>
      <pre><code><?php
echo '$list = ' . e($list) . ';' . PHP_EOL;
echo '$$list = ' . e($varOfVarValue) . '; // создали $' . e($list) . PHP_EOL;
echo '$varRefSource = "test";' . PHP_EOL;
echo '$' . e($refName) . ' = &$varRefSource; // ссылка' . PHP_EOL;
echo '$' . e($refName) . ' = "new value via reference"; // изменили через ссылку' . PHP_EOL;
?></code></pre>
    </div>
  <?php endif; ?>

  <hr>

  <!-- ========================= ЗАДАНИЕ 2 ========================= -->
  <h2 id="t2">Задание 2. Арифметические операции и условный оператор</h2>
  <form method="post">
    <input type="hidden" name="task" value="2">
    <div class="row">
      <div>
        <label>Число x</label>
        <input type="text" name="x" value="<?= isset($_POST['x']) ? e($_POST['x']) : '10' ?>">
      </div>
      <div>
        <label>Число y</label>
        <input type="text" name="y" value="<?= isset($_POST['y']) ? e($_POST['y']) : '3' ?>">
      </div>
    </div>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Выполнить операции</button>
      <button class="btn btn-ghost" type="reset">Сброс</button>
    </div>
  </form>

  <?php if (($_POST['task'] ?? '') === '2'): ?>
    <div class="card">
      <?php
      $x = (float)str_replace(',', '.', ($_POST['x'] ?? 10));
      $y = (float)str_replace(',', '.', ($_POST['y'] ?? 3));

      echo "<h3>Арифметика</h3>";
      echo "x + y = ".($x + $y)."<br>";
      echo "x - y = ".($x - $y)."<br>";
      echo "x * y = ".($x * $y)."<br>";
      echo "x % y = ".(($y==0)? 'недопустимо (деление на 0)' : fmod($x, $y))."<br>";
      echo "x / y = ".(($y==0)? 'недопустимо (деление на 0)' : ($x / $y))."<br>";

      // Инкремент/декремент
      $z = 5;
      $prefixInc  = ++$z; // сначала увеличит, потом вернёт
      $postfixInc = $z++; // сначала вернёт текущее, потом увеличит
      $afterPost  = $z;

      echo "<h3>Инкремент</h3>";
      echo "Старт z=5; ++z => {$prefixInc}; z++ => {$postfixInc}; после z++ z={$afterPost}<br>";

      // Присваивание цепочкой и «на лету»
      $c = $d = 0;
      $d = 8 + ($c = 3);

      echo "<h3>Присваивания</h3>";
      echo "\$c = \$d = 0; затем \$d = 8 + (\$c = 3); => c={$c}, d={$d}<br>";

      // Условный оператор (тернарный) + сравнения
      echo "<h3>Условный оператор и сравнение</h3>";
      $eq = ($x == $y) ? 'x равно y' : 'x не равно y';
      echo $eq."<br>";
      echo '($x == $y) как 1/0: '.(int)($x == $y)."<br>";
      if (($x == $y) == true) echo "Сработал if: x == y<br>";
      ?>
    </div>
  <?php endif; ?>

  <hr>

  <!-- ========================= ЗАДАНИЕ 3 ========================= -->
  <h2 id="t3">Задание 3. Циклы while, do..while, foreach и for</h2>
  <form method="post">
    <input type="hidden" name="task" value="3">
    <fieldset>
      <legend>Параметры для демонстраций</legend>
      <div class="row">
        <div>
          <label>Количество итераций для while/do..while</label>
          <input type="number" min="1" name="n_loop" value="<?= isset($_POST['n_loop']) ? e($_POST['n_loop']) : 5 ?>">
        </div>
        <div>
          <label>Массив для foreach (через запятую)</label>
          <input type="text" name="names" value="<?= isset($_POST['names']) ? e($_POST['names']) : 'Александра,Петр,Игорь' ?>">
        </div>
        <div>
          <label>Верхняя граница для for (вложенные)</label>
          <input type="number" min="1" name="for_n" value="<?= isset($_POST['for_n']) ? e($_POST['for_n']) : 10 ?>">
        </div>
      </div>
    </fieldset>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Показать циклы</button>
      <button class="btn btn-ghost" type="reset">Сброс</button>
    </div>
  </form>

  <?php if (($_POST['task'] ?? '') === '3'): ?>
    <div class="card">
      <?php
      $n_loop = max(1, (int)($_POST['n_loop'] ?? 5));
      $names  = isset($_POST['names']) ? array_filter(array_map('trim', explode(',', $_POST['names']))) : ['Александра','Петр','Игорь'];
      $for_n  = max(1, (int)($_POST['for_n'] ?? 10));

      echo "<h3>while — печать чётных чисел от 1 до ".(2*$n_loop)."</h3>";
      $i = 1;
      $out = [];
      while ($i <= 2*$n_loop) {
        if ($i % 2 == 0) $out[] = $i;
        $i++;
      }
      echo implode(' ', $out) . "<br>";

      echo "<h3>do..while — минимум одна итерация</h3>";
      $k = $n_loop;
      do {
        echo "Итерация: {$k}<br>";
        $k--;
      } while ($k > 0);

      echo "<h3>foreach — приветствие</h3>";
      foreach ($names as $idx => $val) {
        echo "Здравствуйте, ".e($val)."! В списке под номером {$idx}<br>";
      }

      echo "<h3>for (вложенные) + break 2</h3>";
      $kcnt = 0;
      for ($a=1; $a <= $for_n; $a++) {
        echo "\$i={$a}<br>";
        for ($b=1; $b <= $for_n; $b++) {
          echo "&nbsp;&nbsp;\$j={$b}<br>";
          $kcnt++;
          if ($kcnt == 10) { echo "<em>break 2 сработал</em><br>"; break 2; }
        }
      }

      echo "<h3>for — трёхзначные палиндромы (abc == cba)</h3>";
      for ($num=100; $num<=999; $num++) {
        $A = intdiv($num, 100);
        $B = intdiv($num, 10) % 10;
        $C = $num % 10;
        if ($num == 100*$C + 10*$B + $A) {
          echo "Число {$num} — палиндром<br>";
        }
      }
      ?>
    </div>
  <?php endif; ?>

  <hr>

  <!-- ========================= ЗАДАНИЕ 4 ========================= -->
  <h2 id="t4">Задание 4. Чётные трёхзначные, кратные заданному числу</h2>
  <form method="post">
    <input type="hidden" name="task" value="4">
    <div class="row">
      <div>
        <label>Делитель n (10–99). Оставьте пустым — возьмём случайный.</label>
        <input type="number" name="n" min="10" max="99" value="<?= isset($_POST['n']) ? e($_POST['n']) : '' ?>">
      </div>
    </div>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Показать числа</button>
      <button class="btn btn-ghost" type="reset">Сброс</button>
    </div>
  </form>

  <?php if (($_POST['task'] ?? '') === '4'): ?>
    <div class="card">
      <?php
      $n = isset($_POST['n']) && $_POST['n'] !== '' ? (int)$_POST['n'] : rand(10,99);
      if ($n < 10 || $n > 99) {
        echo "Ошибка: n должно быть от 10 до 99.";
      } else {
        echo "Произвольное число n: <strong>{$n}</strong><br>";
        echo "Числа, удовлетворяющие условию (100–999, чётные и кратные n):<br>";
        $buf = [];
        // Оптимизация: стартуем с ближайшего к 100 числа, кратного 2 и n
        // Найдём первый k в [100..999], такой что k % (LCM(2,n)) == 0
        // LCM(2, n) = (2*n)/gcd(2,n)
        // Находим НОК (LCM) числа 2 и n через gcd()
        $g = gcd(2, $n);
        $lcm = (2 * $n) / $g;
        $start = (int)ceil(100 / $lcm) * $lcm;

        for ($i = $start; $i <= 999; $i += $lcm) {
            $buf[] = $i;
        }

        echo $buf ? implode(', ', $buf) : '—';

      }

      ?>
    </div>
  <?php endif; ?>

  <hr>
  <p class="muted">Готово. Все задания реализованы с использованием HTML-форм и серверной обработки на PHP.</p>
</div>
</body>
</html>
