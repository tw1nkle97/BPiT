<?php
/* preview.php
 * Получаем данные с index.php (POST), безопасно выводим,
 * затем готовим форму со скрытыми полями для отправки на greet.php.
 */

// Функции для безопасного вывода
function e($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function eArr($arr)
{
    if (!is_array($arr) || empty($arr))
        return '—';
    return implode(', ', array_map('e', $arr));
}

// Забираем поля
$fio = $_POST['fio'] ?? '';
$birthdate = $_POST['birthdate'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$gender = $_POST['gender'] ?? '';
$edu = $_POST['edu'] ?? '';
$position = $_POST['position'] ?? '';
$experience = $_POST['experience'] ?? '0';
$salary = $_POST['salary'] ?? '';
$skills = $_POST['skills'] ?? [];
$about = $_POST['about'] ?? '';
$has_car = isset($_POST['has_car']) ? 'Да' : 'Нет';
$relocate = isset($_POST['relocate']) ? 'Да' : 'Нет';

// Скрытые служебные
$form_id = $_POST['form_id'] ?? '';
$source = $_POST['source'] ?? '';

// Простая валидация
$errors = [];
if ($fio === '')
    $errors[] = 'Не заполнено поле ФИО.';
if ($email === '')
    $errors[] = 'Не указан Email.';
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL))
    $errors[] = 'Неверный формат Email.';

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Предпросмотр анкеты</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f8fb;
            padding: 20px;
        }

        .card {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .08);
        }

        .row {
            display: grid;
            grid-template-columns: 260px 1fr;
            gap: 10px;
            margin: 6px 0;
        }

        .label {
            color: #475569
        }

        .val {
            font-weight: 600
        }

        .errors {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px 12px;
            border-radius: 8px;
            margin-bottom: 12px
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 16px
        }

        input[type=submit],
        button {
            padding: 10px 14px;
            border-radius: 10px;
            border: 0;
            cursor: pointer
        }

        .primary {
            background: #2563eb;
            color: #fff
        }

        .secondary {
            background: #e2e8f0
        }
    </style>
</head>

<body>
    <div class="card">
        <h1>Предпросмотр анкеты</h1>

        <?php if ($errors): ?>
            <div class="errors">
                <strong>Исправьте ошибки:</strong><br>
                <ul>
                    <?php foreach ($errors as $er): ?>
                        <li><?= e($er) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="actions">
                <button class="secondary" onclick="history.back()">Вернуться к форме</button>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="label">ФИО</div>
                <div class="val"><?= e($fio) ?></div>
            </div>
            <div class="row">
                <div class="label">Дата рождения</div>
                <div class="val"><?= e($birthdate ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Email</div>
                <div class="val"><?= e($email) ?></div>
            </div>
            <div class="row">
                <div class="label">Телефон</div>
                <div class="val"><?= e($phone ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Пол</div>
                <div class="val"><?= e($gender ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Образование</div>
                <div class="val"><?= e($edu ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Позиция</div>
                <div class="val"><?= e($position ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Опыт (лет)</div>
                <div class="val"><?= e($experience) ?></div>
            </div>
            <div class="row">
                <div class="label">Ожидаемая зарплата</div>
                <div class="val"><?= e($salary ?: '—') ?></div>
            </div>
            <div class="row">
                <div class="label">Навыки</div>
                <div class="val"><?= eArr($skills) ?></div>
            </div>
            <div class="row">
                <div class="label">О себе</div>
                <div class="val"><?= nl2br(e($about ?: '—')) ?></div>
            </div>
            <div class="row">
                <div class="label">Есть авто</div>
                <div class="val"><?= e($has_car) ?></div>
            </div>
            <div class="row">
                <div class="label">Готов к переезду</div>
                <div class="val"><?= e($relocate) ?></div>
            </div>

            <!-- Форма-ретранслятор на greet.php: передаём все данные скрытыми полями -->
            <form action="greet.php" method="post" class="actions" style="margin-top:18px">
                <input type="hidden" name="fio" value="<?= e($fio) ?>">
                <input type="hidden" name="position" value="<?= e($position) ?>">
                <input type="hidden" name="email" value="<?= e($email) ?>">
                <input type="hidden" name="experience" value="<?= e($experience) ?>">
                <input type="hidden" name="skills" value="<?= e(is_array($skills) ? implode(', ', $skills) : '') ?>">
                <input type="hidden" name="form_id" value="<?= e($form_id) ?>">
                <input type="hidden" name="source" value="<?= e($source) ?>">

                <input type="submit" class="primary" value="Отправить приветствие">
                <button type="button" class="secondary" onclick="history.back()">Изменить данные</button>
            </form>
        <?php endif; ?>
    </div>
</body>

</html>