<?php /* index.php */ ?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Анкета при приёме на работу</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f8fb;
            padding: 20px;
        }

        .card {
            max-width: 720px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .08);
        }

        h1 {
            margin-top: 0
        }

        fieldset {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            margin: 16px 0;
            padding: 12px 16px;
        }

        legend {
            padding: 0 6px;
            color: #334155
        }

        label {
            display: block;
            margin: 8px 0 4px;
        }

        input[type=text],
        input[type=email],
        input[type=tel],
        input[type=number],
        input[type=date],
        input[type=password],
        select,
        textarea {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-sizing: border-box;
        }

        .row {
            display: flex;
            gap: 12px
        }

        .row>div {
            flex: 1
        }

        .inline {
            display: flex;
            gap: 14px;
            flex-wrap: wrap
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 12px
        }

        button,
        input[type=submit],
        input[type=reset] {
            padding: 10px 14px;
            border-radius: 10px;
            border: 0;
            cursor: pointer
        }

        input[type=submit] {
            background: #2563eb;
            color: #fff
        }

        input[type=reset] {
            background: #e2e8f0
        }
    </style>
</head>

<body>
    <div class="card">
        <h1>Анкета соискателя</h1>
        <!-- Отправляем на preview.php -->
        <form action="preview.php" method="post">
            <!-- Скрытые поля (пример) -->
            <input type="hidden" name="form_id" value="job_application_v1">
            <input type="hidden" name="source" value="landing_hr_01">

            <fieldset>
                <legend>Персональные данные</legend>
                <div class="row">
                    <div>
                        <label>Фамилия Имя Отчество</label>
                        <input type="text" name="fio" required>
                    </div>
                    <div>
                        <label>Дата рождения</label>
                        <input type="date" name="birthdate">
                    </div>
                </div>
                <div class="row">
                    <div>
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>
                    <div>
                        <label>Телефон</label>
                        <input type="tel" name="phone" placeholder="+7XXXXXXXXXX">
                    </div>
                </div>
                <label>Пол</label>
                <div class="inline">
                    <label><input type="radio" name="gender" value="Мужской" checked> Мужской</label>
                    <label><input type="radio" name="gender" value="Женский"> Женский</label>
                </div>
            </fieldset>

            <fieldset>
                <legend>Образование и позиция</legend>
                <div class="row">
                    <div>
                        <label>Уровень образования</label>
                        <select name="edu">
                            <option value="Высшее" selected>Высшее</option>
                            <option value="Незаконченное высшее">Незаконченное высшее</option>
                            <option value="Среднее специальное">Среднее специальное</option>
                            <option value="Среднее полное">Среднее полное</option>
                        </select>
                    </div>
                    <div>
                        <label>Желаемая позиция</label>
                        <select name="position">
                            <option value="PHP-разработчик" selected>PHP-разработчик</option>
                            <option value="Веб-разработчик">Веб-разработчик</option>
                            <option value="Тестировщик">Тестировщик</option>
                            <option value="Системный администратор">Системный администратор</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div>
                        <label>Опыт (лет)</label>
                        <input type="number" name="experience" min="0" step="1" value="0">
                    </div>
                    <div>
                        <label>Ожидаемая зарплата (₽/мес)</label>
                        <input type="number" name="salary" min="0" step="1000">
                    </div>
                </div>
            </fieldset>

            <fieldset>
                <legend>Навыки</legend>
                <div class="inline">
                    <!-- Чекбоксы отправляются массивом skills[] -->
                    <label><input type="checkbox" name="skills[]" value="PHP" checked> PHP</label>
                    <label><input type="checkbox" name="skills[]" value="MySQL"> MySQL</label>
                    <label><input type="checkbox" name="skills[]" value="HTML/CSS"> HTML/CSS</label>
                    <label><input type="checkbox" name="skills[]" value="JavaScript"> JavaScript</label>
                    <label><input type="checkbox" name="skills[]" value="Git"> Git</label>
                    <label><input type="checkbox" name="skills[]" value="Linux"> Linux</label>
                </div>
                <label>О себе</label>
                <textarea name="about" rows="4" placeholder="Кратко опишите опыт и достижения"></textarea>
                <div class="inline" style="margin-top:8px">
                    <label><input type="checkbox" name="has_car" value="1"> Есть личный автомобиль</label>
                    <label><input type="checkbox" name="relocate" value="1"> Готов к переезду</label>
                </div>
            </fieldset>

            <fieldset>
                <legend>Безопасность</legend>
                <div class="row">
                    <div>
                        <label>Пароль для личного кабинета (пример скрытого поля тоже передаём выше)</label>
                        <input type="password" name="password" placeholder="минимум 6 символов">
                    </div>
                </div>
            </fieldset>

            <div class="actions">
                <input type="submit" value="Предпросмотр анкеты">
                <input type="reset" value="Сброс">
            </div>
        </form>
    </div>
</body>

</html>