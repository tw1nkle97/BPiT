<?php
/**
 * ЗАДАНИЕ 5 с формой:
 * Вводим стороны a, b и угол C (в градусах).
 * Скрипт считает площадь и радиус описанной окружности треугольника.
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $a = floatval($_POST["a"]);
    $b = floatval($_POST["b"]);
    $C_deg = floatval($_POST["C"]);

    if ($a > 0 && $b > 0 && $C_deg > 0 && $C_deg < 180) {
        $C = deg2rad($C_deg);
        $sinC = sin($C);

        if ($sinC != 0) {
            $S = 0.5 * $a * $b * $sinC; // площадь
            $c = sqrt($a * $a + $b * $b - 2 * $a * $b * cos($C)); // 3-я сторона
            $R = $c / (2 * $sinC); // радиус описанной окружности
            $result = "Площадь треугольника = " . number_format($S, 3, '.', ' ') . "<br>"
                . "Третья сторона c = " . number_format($c, 3, '.', ' ') . "<br>"
                . "Радиус описанной окружности = " . number_format($R, 3, '.', ' ');
        } else {
            $result = "Ошибка: угол недопустим (sin(C) = 0).";
        }
    } else {
        $result = "Ошибка: стороны и угол должны быть > 0, угол < 180°.";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Задание 5 — Линейные алгоритмы</title>
</head>

<body>
    <h2>Задание 5: Площадь и радиус описанной окружности</h2>
    <form method="post">
        Сторона a: <input type="number" step="0.01" name="a" required><br><br>
        Сторона b: <input type="number" step="0.01" name="b" required><br><br>
        Угол C (градусы): <input type="number" step="0.01" name="C" required><br><br>
        <input type="submit" value="Рассчитать">
    </form>
    <?php if (isset($result)) {
        echo "<h3>Результат</h3>$result";
    } ?>
</body>

</html>