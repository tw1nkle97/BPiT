<?php
/**
 * ЗАДАНИЕ 7 с формой:
 * Пользователь задаёт диапазон чисел.
 * Скрипт выводит таблицу квадратов для этих чисел.
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $start = intval($_POST["start"]);
    $end = intval($_POST["end"]);

    if ($start < $end && $start > 0) {
        $table = "<table border='1' cellpadding='5' cellspacing='0'>";
        $table .= "<tr><th>Число</th><th>Квадрат</th></tr>";
        for ($i = $start; $i <= $end; $i++) {
            $table .= "<tr><td>$i</td><td>" . ($i * $i) . "</td></tr>";
        }
        $table .= "</table>";
    } else {
        $table = "Ошибка: начальное число должно быть меньше конечного, и больше 0.";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Задание 7 — Таблица квадратов</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            margin-top: 15px;
        }

        th,
        td {
            border: 1px solid #999;
            padding: 6px;
            text-align: center;
        }

        th {
            background: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background: #f2f2f2;
        }
    </style>
</head>

<body>
    <h2>Задание 7: Таблица квадратов</h2>
    <form method="post">
        Начальное число: <input type="number" name="start" required><br><br>
        Конечное число: <input type="number" name="end" required><br><br>
        <input type="submit" value="Показать таблицу">
    </form>
    <?php if (isset($table)) {
        echo "<h3>Результат</h3>$table";
    } ?>
</body>

</html>