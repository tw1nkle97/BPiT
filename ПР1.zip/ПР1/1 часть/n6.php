<?php
// Если форма отправлена
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $R_circle = floatval($_POST["R_circle"]);
    $a = floatval($_POST["a"]);

    if ($R_circle <= 0 || $a <= 0) {
        $result = "Ошибка: радиус и сторона должны быть положительными числами.";
    } else {
        // Радиус описанной окружности равностороннего треугольника
        $R_triangle = $a / sqrt(3);

        // Проверка
        if ($R_circle >= $R_triangle) {
            $result = "✅ Треугольник помещается в круг.<br>
                       Радиус круга = $R_circle<br>
                       Сторона треугольника = $a<br>
                       Радиус описанной окружности треугольника = "
                . number_format($R_triangle, 3, '.', ' ');
        } else {
            $result = "❌ Треугольник не помещается в круг.<br>
                       Радиус круга = $R_circle<br>
                       Сторона треугольника = $a<br>
                       Радиус описанной окружности треугольника = "
                . number_format($R_triangle, 3, '.', ' ');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Задание 6 — Проверка треугольника и круга</title>
</head>

<body>
    <h2>Задание 6: Проверка, помещается ли равносторонний треугольник в круг</h2>
    <form method="post">
        <label>Радиус круга (R):</label><br>
        <input type="number" step="0.01" name="R_circle" required><br><br>

        <label>Сторона треугольника (a):</label><br>
        <input type="number" step="0.01" name="a" required><br><br>

        <input type="submit" value="Проверить">
    </form>

    <?php
    if (isset($result)) {
        echo "<h3>Результат</h3>";
        echo $result;
    }
    ?>
</body>

</html>