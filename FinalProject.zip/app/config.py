# config.py
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "1234",
    "database": "custom_shop",
    "port": 3306,
}
SECRET_KEY = "1234"