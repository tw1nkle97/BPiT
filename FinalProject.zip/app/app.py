# app.py
from flask import (
    Flask, render_template, request,
    redirect, url_for, session, flash
)
import pymysql
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

from config import DB_CONFIG, SECRET_KEY

# =========================
# Блок: инициализация приложения
# =========================

app = Flask(__name__)
app.secret_key = SECRET_KEY


# =========================
# Блок: функции работы с БД
# =========================

def get_connection():
    """Создание подключения к БД."""
    return pymysql.connect(
        cursorclass=pymysql.cursors.DictCursor,
        **DB_CONFIG
    )


def query(sql, params=None, fetchone=False, commit=False):
    """Утилита для выполнения запросов к БД."""
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, params or ())
            if commit:
                conn.commit()
            if fetchone:
                return cursor.fetchone()
            return cursor.fetchall()
    finally:
        conn.close()


# =========================
# Блок: вспомогательные функции авторизации
# =========================

def current_user():
    """Получить текущего пользователя из сессии."""
    user_id = session.get("user_id")
    if not user_id:
        return None
    return query("SELECT * FROM users WHERE id = %s", (user_id,), fetchone=True)


def require_login(role=None):
    """
    Простая проверка авторизации.
    Если пользователь не авторизован или не имеет нужной роли,
    возвращает redirect-ответ.
    Если всё ок — возвращает словарь с данными пользователя.
    """
    user = current_user()
    if not user:
        flash("Необходимо войти в систему.", "warning")
        return redirect(url_for("login"))
    # допустим: role_id = 1 — обычный пользователь, 2 — администратор
    if role == "admin" and user["role_id"] != 2:
        flash("Недостаточно прав для доступа в админ-панель.", "danger")
        return redirect(url_for("index"))
    return user


# =====================================================
# ПУБЛИЧНАЯ ЧАСТЬ (соответствует функционалу Таблицы 2)
# =====================================================

# --- index.py: Просмотр главной страницы ---
@app.route("/")
def index():
    """Просмотр главной страницы (акции, популярные товары)."""
    products = query(
        "SELECT * FROM products WHERE is_active = 1 ORDER BY created_at DESC LIMIT 8"
    )
    return render_template("index.html", products=products, user=current_user())


# --- register.py: Регистрация пользователя ---
@app.route("/register", methods=["GET", "POST"])
def register():
    """Регистрация нового пользователя."""
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        name = request.form.get("name")

        # Валидация обязательных полей
        if not email or not password or not name:
            flash("Заполните все обязательные поля.", "danger")
            return render_template("register.html")

        # Проверка уникальности email
        existing = query(
            "SELECT id FROM users WHERE email = %s", (email,), fetchone=True
        )
        if existing:
            flash("Пользователь с таким email уже существует.", "danger")
            return render_template("register.html")

        password_hash = generate_password_hash(password)

        # По умолчанию роль_id = 1 (обычный пользователь)
        query(
            """
            INSERT INTO users (role_id, email, password_hash, full_name, created_at)
            VALUES (1, %s, %s, %s, %s)
            """,
            (email, password_hash, name, datetime.now()),
            commit=True,
        )

        flash("Регистрация успешно завершена. Теперь войдите.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", user=current_user())


# --- login.py: Авторизация пользователя ---
@app.route("/login", methods=["GET", "POST"])
def login():
    """Авторизация пользователя."""
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = query(
            "SELECT * FROM users WHERE email = %s", (email,), fetchone=True
        )
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Неверный email или пароль.", "danger")
            return render_template("login.html")

        session["user_id"] = user["id"]
        flash("Вы успешно вошли в систему.", "success")
        return redirect(url_for("index"))

    return render_template("login.html", user=current_user())


# --- logout.py: Выход из системы ---
@app.route("/logout")
def logout():
    """Завершение сессии."""
    session.clear()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("index"))


# --- catalog.py: Просмотр каталога ---
@app.route("/catalog")
def catalog():
    """Просмотр каталога товаров с фильтром по категории."""
    category_id = request.args.get("category_id")
    categories = query("SELECT * FROM categories ORDER BY name")

    if category_id:
        products = query(
            "SELECT * FROM products WHERE is_active = 1 AND category_id = %s",
            (category_id,),
        )
    else:
        products = query("SELECT * FROM products WHERE is_active = 1")

    return render_template(
        "catalog.html",
        categories=categories,
        products=products,
        active_category=category_id,
        user=current_user(),
    )


# --- product.py: Карточка товара ---
@app.route("/product/<int:product_id>")
def product(product_id):
    """Карточка товара с изображениями и отзывами."""
    product = query(
        "SELECT * FROM products WHERE id = %s AND is_active = 1",
        (product_id,),
        fetchone=True,
    )
    if not product:
        flash("Товар не найден.", "warning")
        return redirect(url_for("catalog"))

    images = query("SELECT * FROM product_images WHERE product_id = %s", (product_id,))
    reviews = query(
        """
        SELECT r.*, u.full_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.product_id = %s AND r.is_approved = 1
        ORDER BY r.created_at DESC
        """,
        (product_id,),
    )

    return render_template(
        "product.html",
        product=product,
        images=images,
        reviews=reviews,
        user=current_user(),
    )


# --- designer.py: Конструктор дизайна ---
@app.route("/designer/<int:product_id>", methods=["GET", "POST"])
def designer(product_id):
    """Создание/редактирование пользовательского дизайна."""
    user = require_login()
    if not isinstance(user, dict):
        return user

    product = query("SELECT * FROM products WHERE id = %s", (product_id,), fetchone=True)
    if not product:
        flash("Товар не найден.", "warning")
        return redirect(url_for("catalog"))

    if request.method == "POST":
        title = request.form.get("title")
        # Обработка файла опускается, для учебного проекта можно сделать заглушку
        file_path = "uploads/mock.png"

        if not title:
            flash("Название дизайна обязательно.", "danger")
            return render_template("designer.html", product=product, user=user)

        query(
            """
            INSERT INTO designs (user_id, product_id, title, file_path, created_at)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user["id"], product_id, title, file_path, datetime.now()),
            commit=True,
        )
        flash("Дизайн сохранён и отправлен на модерацию.", "success")
        return redirect(url_for("product", product_id=product_id))

    return render_template("designer.html", product=product, user=user)


# --- cart_add.py: Добавление в корзину ---
@app.route("/cart/add", methods=["POST"])
def cart_add():
    """Добавление товара в корзину (в сессии)."""
    product_id = request.form.get("product_id")
    quantity = int(request.form.get("quantity", 1))

    if not product_id:
        flash("Неверный товар.", "danger")
        return redirect(url_for("catalog"))

    cart = session.get("cart", {})
    cart[product_id] = cart.get(product_id, 0) + quantity
    session["cart"] = cart
    flash("Товар добавлен в корзину.", "success")
    return redirect(url_for("cart"))


# --- cart.py: Просмотр и редактирование корзины ---
@app.route("/cart", methods=["GET", "POST"])
def cart():
    """Просмотр и редактирование корзины."""
    cart = session.get("cart", {})

    # Обновление количества/удаление
    if request.method == "POST":
        for key, value in request.form.items():
            if key.startswith("qty_"):
                pid = key.split("_", 1)[1]
                try:
                    qty = int(value)
                    if qty <= 0:
                        cart.pop(pid, None)
                    else:
                        cart[pid] = qty
                except ValueError:
                    pass
        session["cart"] = cart
        flash("Корзина обновлена.", "info")
        return redirect(url_for("cart"))

    if not cart:
        products = []
        total = 0
    else:
        ids = list(map(int, cart.keys()))
        placeholders = ",".join(["%s"] * len(ids))
        products = query(
            f"SELECT * FROM products WHERE id IN ({placeholders})", ids
        )
        total = 0
        for p in products:
            qty = cart[str(p["id"])]
            p["quantity"] = qty
            p["subtotal"] = qty * float(p["base_price"])
            total += p["subtotal"]

    return render_template(
        "cart.html", cart_items=products, total=total, user=current_user()
    )


# --- checkout.py: Оформление заказа ---
@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    """Оформление заказа: проверка данных и запись в БД."""
    user = require_login()
    if not isinstance(user, dict):
        return user

    cart = session.get("cart", {})
    if not cart:
        flash("Корзина пуста.", "warning")
        return redirect(url_for("catalog"))

    if request.method == "POST":
        address = request.form.get("address")
        delivery_method = request.form.get("delivery_method")
        payment_method = request.form.get("payment_method")
        comment = request.form.get("comment")

        if not address or not delivery_method or not payment_method:
            flash("Заполните все обязательные поля.", "danger")
            return render_template("checkout.html", user=user)

        ids = list(map(int, cart.keys()))
        placeholders = ",".join(["%s"] * len(ids))
        products = query(
            f"SELECT * FROM products WHERE id IN ({placeholders})", ids
        )

        total = 0
        for p in products:
            qty = cart[str(p["id"])]
            total += qty * float(p["base_price"])

        # статус_id = 1 — "Новый"
        query(
            """
            INSERT INTO orders (user_id, status_id, created_at, total_amount,
                                delivery_address, delivery_method, payment_method, comment)
            VALUES (%s, 1, %s, %s, %s, %s, %s, %s)
            """,
            (user["id"], datetime.now(), total, address,
             delivery_method, payment_method, comment),
            commit=True,
        )

        order_id = query("SELECT LAST_INSERT_ID() AS id", fetchone=True)["id"]

        for p in products:
            qty = cart[str(p["id"])]
            query(
                """
                INSERT INTO order_items (order_id, product_id, quantity, unit_price)
                VALUES (%s, %s, %s, %s)
                """,
                (order_id, p["id"], qty, p["base_price"]),
                commit=True,
            )

        session["cart"] = {}
        flash("Заказ успешно оформлен.", "success")
        return redirect(url_for("orders"))

    return render_template("checkout.html", user=user)


# --- orders.py: История заказов ---
@app.route("/orders")
def orders():
    """Просмотр истории заказов текущего пользователя."""
    user = require_login()
    if not isinstance(user, dict):
        return user

    orders_list = query(
        """
        SELECT o.*, s.name AS status_name
        FROM orders o
        JOIN order_statuses s ON o.status_id = s.id
        WHERE o.user_id = %s
        ORDER BY o.created_at DESC
        """,
        (user["id"],),
    )
    return render_template("orders.html", orders=orders_list, user=user)


# --- profile.py: Управление профилем ---
@app.route("/profile", methods=["GET", "POST"])
def profile():
    """Просмотр и изменение данных профиля."""
    user = require_login()
    if not isinstance(user, dict):
        return user

    if request.method == "POST":
        full_name = request.form.get("full_name")
        phone = request.form.get("phone")

        query(
            "UPDATE users SET full_name = %s, phone = %s WHERE id = %s",
            (full_name, phone, user["id"]),
            commit=True,
        )
        flash("Профиль обновлен.", "success")
        return redirect(url_for("profile"))

    return render_template("profile.html", user=user)


# --- reviews.py: Добавление отзыва ---
@app.route("/product/<int:product_id>/review", methods=["POST"])
def add_review(product_id):
    """Добавление отзыва о товаре (с последующей модерацией)."""
    user = require_login()
    if not isinstance(user, dict):
        return user

    rating = int(request.form.get("rating", 5))
    text = request.form.get("text", "").strip()

    if not text:
        flash("Текст отзыва не может быть пустым.", "danger")
        return redirect(url_for("product", product_id=product_id))

    query(
        """
        INSERT INTO reviews (product_id, user_id, rating, text, created_at, is_approved)
        VALUES (%s, %s, %s, %s, %s, 0)
        """,
        (product_id, user["id"], rating, text, datetime.now()),
        commit=True,
    )
    flash("Отзыв отправлен на модерацию.", "info")
    return redirect(url_for("product", product_id=product_id))


# =====================================================
# АДМИН-ПАНЕЛЬ (полная реализация функций Таблицы 2)
# =====================================================

# --- admin/index.py: Панель администратора ---
@app.route("/admin")
def admin_index():
    """Главная страница панели администратора."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    stats = {
        "users": query("SELECT COUNT(*) AS c FROM users", fetchone=True)["c"],
        "orders": query("SELECT COUNT(*) AS c FROM orders", fetchone=True)["c"],
        "products": query("SELECT COUNT(*) AS c FROM products", fetchone=True)["c"],
        "reviews": query("SELECT COUNT(*) AS c FROM reviews", fetchone=True)["c"],
    }

    return render_template("admin_index.html", user=user, stats=stats)


# --- admin/products.py: Управление товарами ---
@app.route("/admin/products")
def admin_products():
    """Список товаров в админке."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    products = query(
        """
        SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        ORDER BY p.created_at DESC
        """
    )
    return render_template("admin_products.html", user=user, products=products)


@app.route("/admin/products/new", methods=["GET", "POST"])
def admin_product_new():
    """Создание нового товара."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    categories = query("SELECT * FROM categories ORDER BY name")

    if request.method == "POST":
        name = request.form.get("name")
        category_id = request.form.get("category_id")
        base_price = request.form.get("base_price")
        description = request.form.get("description")

        if not name or not category_id or not base_price:
            flash("Заполните обязательные поля.", "danger")
            return render_template(
                "admin_product_form.html",
                user=user,
                categories=categories,
                product=None,
            )

        query(
            """
            INSERT INTO products (category_id, name, description, base_price, is_active, created_at)
            VALUES (%s, %s, %s, %s, 1, %s)
            """,
            (category_id, name, description, base_price, datetime.now()),
            commit=True,
        )
        flash("Товар добавлен.", "success")
        return redirect(url_for("admin_products"))

    return render_template(
        "admin_product_form.html", user=user, categories=categories, product=None
    )


@app.route("/admin/products/<int:product_id>/edit", methods=["GET", "POST"])
def admin_product_edit(product_id):
    """Редактирование товара."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    product = query(
        "SELECT * FROM products WHERE id = %s", (product_id,), fetchone=True
    )
    if not product:
        flash("Товар не найден.", "warning")
        return redirect(url_for("admin_products"))

    categories = query("SELECT * FROM categories ORDER BY name")

    if request.method == "POST":
        name = request.form.get("name")
        category_id = request.form.get("category_id")
        base_price = request.form.get("base_price")
        description = request.form.get("description")
        is_active = 1 if request.form.get("is_active") == "on" else 0

        query(
            """
            UPDATE products
            SET category_id = %s, name = %s, description = %s,
                base_price = %s, is_active = %s
            WHERE id = %s
            """,
            (category_id, name, description, base_price, is_active, product_id),
            commit=True,
        )
        flash("Товар обновлен.", "success")
        return redirect(url_for("admin_products"))

    return render_template(
        "admin_product_form.html",
        user=user,
        categories=categories,
        product=product,
    )


@app.route("/admin/products/<int:product_id>/delete", methods=["POST"])
def admin_product_delete(product_id):
    """Удаление товара."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query("DELETE FROM products WHERE id = %s", (product_id,), commit=True)
    flash("Товар удален.", "info")
    return redirect(url_for("admin_products"))


# --- admin/categories.py: Управление категориями ---
@app.route("/admin/categories", methods=["GET", "POST"])
def admin_categories():
    """Управление категориями (список и добавление)."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    if request.method == "POST":
        name = request.form.get("name")
        parent_id = request.form.get("parent_id") or None
        if not name:
            flash("Название категории обязательно.", "danger")
        else:
            query(
                "INSERT INTO categories (name, parent_id) VALUES (%s, %s)",
                (name, parent_id),
                commit=True,
            )
            flash("Категория добавлена.", "success")
            return redirect(url_for("admin_categories"))

    categories = query("SELECT * FROM categories ORDER BY name")
    return render_template("admin_categories.html", user=user, categories=categories)


@app.route("/admin/categories/<int:category_id>/delete", methods=["POST"])
def admin_category_delete(category_id):
    """Удаление категории."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query("DELETE FROM categories WHERE id = %s", (category_id,), commit=True)
    flash("Категория удалена.", "info")
    return redirect(url_for("admin_categories"))


# --- admin/designs.py: Модерация дизайнов ---
@app.route("/admin/designs")
def admin_designs():
    """Просмотр и модерация пользовательских дизайнов."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    designs = query(
        """
        SELECT d.*, u.full_name AS user_name, p.name AS product_name
        FROM designs d
        JOIN users u ON d.user_id = u.id
        JOIN products p ON d.product_id = p.id
        ORDER BY d.created_at DESC
        """
    )
    return render_template("admin_designs.html", user=user, designs=designs)


@app.route("/admin/designs/<int:design_id>/approve", methods=["POST"])
def admin_design_approve(design_id):
    """Одобрить дизайн."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query(
        "UPDATE designs SET is_approved = 1 WHERE id = %s",
        (design_id,),
        commit=True,
    )
    flash("Дизайн одобрен.", "success")
    return redirect(url_for("admin_designs"))


@app.route("/admin/designs/<int:design_id>/delete", methods=["POST"])
def admin_design_delete(design_id):
    """Удалить дизайн."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query("DELETE FROM designs WHERE id = %s", (design_id,), commit=True)
    flash("Дизайн удален.", "info")
    return redirect(url_for("admin_designs"))


# --- admin/orders.py: Управление заказами ---
@app.route("/admin/orders")
def admin_orders():
    """Просмотр всех заказов и изменение статусов."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    orders = query(
        """
        SELECT o.*, u.full_name AS user_name, s.name AS status_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN order_statuses s ON o.status_id = s.id
        ORDER BY o.created_at DESC
        """
    )
    statuses = query("SELECT * FROM order_statuses")
    return render_template("admin_orders.html", user=user, orders=orders, statuses=statuses)


@app.route("/admin/orders/<int:order_id>/status", methods=["POST"])
def admin_order_change_status(order_id):
    """Изменение статуса заказа."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    status_id = request.form.get("status_id")
    query(
        "UPDATE orders SET status_id = %s WHERE id = %s",
        (status_id, order_id),
        commit=True,
    )
    flash("Статус заказа обновлен.", "success")
    return redirect(url_for("admin_orders"))


# --- admin/users.py: Управление пользователями ---
@app.route("/admin/users")
def admin_users():
    """Список пользователей, ролей и статуса."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    users = query(
        """
        SELECT u.*, r.name AS role_name
        FROM users u
        JOIN roles r ON u.role_id = r.id
        ORDER BY u.created_at DESC
        """
    )
    roles = query("SELECT * FROM roles")
    return render_template("admin_users.html", user=user, users=users, roles=roles)


@app.route("/admin/users/<int:user_id>/role", methods=["POST"])
def admin_user_change_role(user_id):
    """Изменение роли пользователя."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    role_id = request.form.get("role_id")
    query(
        "UPDATE users SET role_id = %s WHERE id = %s",
        (role_id, user_id),
        commit=True,
    )
    flash("Роль пользователя обновлена.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<int:user_id>/toggle", methods=["POST"])
def admin_user_toggle_active(user_id):
    """Блокировка/разблокировка пользователя."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    u = query("SELECT is_active FROM users WHERE id = %s", (user_id,), fetchone=True)
    if not u:
        flash("Пользователь не найден.", "warning")
        return redirect(url_for("admin_users"))

    new_value = 0 if u["is_active"] else 1
    query(
        "UPDATE users SET is_active = %s WHERE id = %s",
        (new_value, user_id),
        commit=True,
    )
    flash("Статус пользователя обновлен.", "success")
    return redirect(url_for("admin_users"))


# --- admin/reviews.py: Модерация отзывов ---
@app.route("/admin/reviews")
def admin_reviews():
    """Список отзывов для модерации."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    reviews = query(
        """
        SELECT r.*, u.full_name AS user_name, p.name AS product_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        JOIN products p ON r.product_id = p.id
        ORDER BY r.created_at DESC
        """
    )
    return render_template("admin_reviews.html", user=user, reviews=reviews)


@app.route("/admin/reviews/<int:review_id>/approve", methods=["POST"])
def admin_review_approve(review_id):
    """Одобрение отзыва."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query(
        "UPDATE reviews SET is_approved = 1 WHERE id = %s",
        (review_id,),
        commit=True,
    )
    flash("Отзыв одобрен.", "success")
    return redirect(url_for("admin_reviews"))


@app.route("/admin/reviews/<int:review_id>/delete", methods=["POST"])
def admin_review_delete(review_id):
    """Удаление отзыва."""
    user = require_login(role="admin")
    if not isinstance(user, dict):
        return user

    query("DELETE FROM reviews WHERE id = %s", (review_id,), commit=True)
    flash("Отзыв удален.", "info")
    return redirect(url_for("admin_reviews"))


# =========================
# Точка входа
# =========================

if __name__ == "__main__":
    app.run(debug=True)
