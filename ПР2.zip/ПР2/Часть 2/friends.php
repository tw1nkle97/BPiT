<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

// Имя файла, в который будут записываться данные
$file = __DIR__ . '/friends.txt';

// Обработка формы
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $surname = trim($_POST['surname'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if ($name === '' || $surname === '' || $phone === '') {
        $message = '⚠️ Пожалуйста, заполните все поля!';
    } else {
        // Формируем строку для добавления (через пробел, как по условию)
        $record = $name . ' ' . $surname . ' ' . $phone . ' ';

        // Функция file_put_contents с флагом FILE_APPEND добавляет в конец файла
        // Если файла нет, он будет создан автоматически
        if (file_put_contents($file, $record, FILE_APPEND | LOCK_EX) !== false) {
            $message = '✅ Запись успешно добавлена в файл.';
        } else {
            $message = '❌ Ошибка при записи в файл.';
        }
    }
}

// Для наглядности можно показать содержимое файла (если он существует)
$content = file_exists($file) ? file_get_contents($file) : '(Файл пока не создан)';
?>
<!doctype html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Задание 6 — Дополнение файла</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }

        form {
            margin-bottom: 20px;
        }

        input {
            padding: 6px;
            margin: 4px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 8px 14px;
            background: #2d6cdf;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background: #1f57be;
        }

        .message {
            font-weight: bold;
            margin-top: 10px;
        }

        textarea {
            width: 100%;
            height: 100px;
            font-family: monospace;
        }
    </style>
</head>

<body>

    <h1>Практическая работа №2 — Задание 6</h1>
    <p>Программа дописывает в файл имя, фамилию и номер телефона.</p>

    <form method="post" action="">
        <label>Имя: <input type="text" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"></label><br>
        <label>Фамилия: <input type="text" name="surname"
                value="<?= htmlspecialchars($_POST['surname'] ?? '') ?>"></label><br>
        <label>Телефон: <input type="text" name="phone"
                value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"></label><br>
        <button type="submit">Добавить запись</button>
    </form>

    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <h3>Содержимое файла:</h3>
    <textarea readonly><?= htmlspecialchars($content) ?></textarea>

</body>

</html>