<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

/**
 * Данные библиотеки: книги, газеты, журналы.
 * Поля:
 * - type: book | newspaper | magazine
 * - title: string
 * - year: int (только для книг)
 * - date: YYYY-MM-DD (для газет и журналов)
 * - author: string (для книг)
 * - editor: string (для газет)
 * - editorial_board: string[] (для журналов)
 * - pages: int (объём, условно — страниц)
 */
$items = [
    [
        'type' => 'book',
        'title' => 'Чистый код',
        'year' => 2019,
        'author' => 'Роберт Мартин',
        'pages' => 464,
    ],
    [
        'type' => 'book',
        'title' => 'PHP 8. В подлиннике',
        'year' => 2021,
        'author' => 'Сергей Скворцов',
        'pages' => 640,
    ],
    [
        'type' => 'newspaper',
        'title' => 'Ежедневные вести',
        'date' => '2021-03-15',
        'editor' => 'Иван Петров',
        'pages' => 24,
    ],
    [
        'type' => 'magazine',
        'title' => 'Наука и жизнь',
        'date' => '2020-11-01',
        'editorial_board' => ['Е. Смирнова', 'Д. Кузнецов', 'Л. Орлова'],
        'pages' => 120,
    ],
    [
        'type' => 'newspaper',
        'title' => 'Городские новости',
        'date' => '2019-12-31',
        'editor' => 'Алексей Романов',
        'pages' => 16,
    ],
    [
        'type' => 'magazine',
        'title' => 'Web-разработка сегодня',
        'date' => '2021-06-10',
        'editorial_board' => ['С. Соколов', 'Н. Белова'],
        'pages' => 96,
    ],
];

/**
 * Валидация года (четыре цифры, 1500–2100 условно).
 */
function validate_year(?string $raw): ?int
{
    if ($raw === null || $raw === '')
        return null;
    $raw = trim($raw);
    if (!preg_match('/^\d{4}$/', $raw))
        return null;
    $y = (int) $raw;
    return ($y >= 1500 && $y <= 2100) ? $y : null;
}

/**
 * Унифицированное получение года из элемента.
 * Для книг — из поля year, для газет/журналов — из поля date (YYYY-MM-DD).
 */
function get_year(array $item): ?int
{
    if (($item['type'] ?? '') === 'book') {
        return isset($item['year']) ? (int) $item['year'] : null;
    }
    if (!empty($item['date'])) {
        try {
            $dt = new DateTime($item['date']);
            return (int) $dt->format('Y');
        } catch (Exception $e) {
            return null;
        }
    }
    return null;
}

/**
 * Фильтрация по году.
 */
function filter_by_year(array $items, int $year): array
{
    return array_values(array_filter($items, function (array $it) use ($year) {
        return get_year($it) === $year;
    }));
}

/**
 * Форматирование одной записи в HTML-блок.
 * Показывает только релевантные полям типа издания.
 */
function render_item(array $it): string
{
    $type = $it['type'] ?? 'unknown';
    $title = htmlspecialchars($it['title'] ?? 'Без названия', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $pages = isset($it['pages']) ? (int) $it['pages'] : null;

    $common = "<strong>{$title}</strong><br>";

    if ($type === 'book') {
        $year = isset($it['year']) ? (int) $it['year'] : null;
        $author = htmlspecialchars($it['author'] ?? '—', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $lines = [
            "Тип: книга",
            "Год выпуска: " . ($year ?? 'неизвестно'),
            "Автор: {$author}",
            "Объём: " . ($pages !== null ? $pages . " стр." : "—"),
        ];
    } elseif ($type === 'newspaper') {
        $date = htmlspecialchars($it['date'] ?? '—', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $editor = htmlspecialchars($it['editor'] ?? '—', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $lines = [
            "Тип: газета",
            "Дата выпуска: {$date}",
            "Редактор: {$editor}",
            "Объём: " . ($pages !== null ? $pages . " стр." : "—"),
        ];
    } elseif ($type === 'magazine') {
        $date = htmlspecialchars($it['date'] ?? '—', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $board = $it['editorial_board'] ?? [];
        $boardStr = $board ? htmlspecialchars(implode(', ', $board), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') : '—';
        $lines = [
            "Тип: журнал",
            "Дата выпуска: {$date}",
            "Редколлегия: {$boardStr}",
            "Объём: " . ($pages !== null ? $pages . " стр." : "—"),
        ];
    } else {
        $lines = ["Тип: неизвестен"];
    }

    return "<div style='padding:10px;border:1px solid #ddd;border-radius:8px;margin:8px 0;background:#fafafa'>"
        . $common
        . "<small>" . implode('<br>', $lines) . "</small>"
        . "</div>";
}

/**
 * Удобный вывод группы результатов.
 */
function render_list(array $items, ?int $year): string
{
    if ($year === null) {
        $hint = "<em>Укажите год и нажмите «Показать».</em>";
        return "<p>{$hint}</p>";
    }
    if (!$items) {
        return "<p><strong>Ничего не найдено</strong> за {$year} год.</p>";
    }
    $out = "<h3>Издания, вышедшие в {$year} году</h3>";
    foreach ($items as $it) {
        $out .= render_item($it);
    }
    return $out;
}

// --- Контроллерная логика ---
$year = validate_year($_GET['year'] ?? null);
$filtered = $year !== null ? filter_by_year($items, $year) : [];

// Дополнительно отсортируем результаты по дате/году (сначала новые)
usort($filtered, function (array $a, array $b) {
    return (get_year($b) <=> get_year($a));
});

?>
<!doctype html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Библиотека — фильтр по году</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
            line-height: 1.5;
            padding: 20px;
        }

        form {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }

        input[type="number"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
            width: 140px;
        }

        button {
            padding: 8px 14px;
            border: 0;
            background: #2d6cdf;
            color: #fff;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background: #1f57be;
        }
    </style>
</head>

<body>
    <h1>Библиотека: книги, газеты, журналы</h1>
    <p>Задание: вывести информацию об изданиях, вышедших в заданном году.</p>

    <form method="get" action="">
        <label for="year">Год:</label>
        <input type="number" id="year" name="year" min="1500" max="2100" step="1"
            value="<?= htmlspecialchars($_GET['year'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
        <button type="submit">Показать</button>
        <?php if ($year === null && isset($_GET['year'])): ?>
            <span style="color:#b00020"> Введите корректный год (формат YYYY, 1500–2100).</span>
        <?php endif; ?>
    </form>

    <?= render_list($filtered, $year) ?>

    <hr>
    <details>
        <summary>Пояснения (для проверки работы с массивами и функциями)</summary>
        <ul>
            <li>Данные хранятся в одном массиве <code>$items</code> с разными типами.</li>
            <li>Пользовательские функции:
                <ul>
                    <li><code>validate_year</code> — проверка года;</li>
                    <li><code>get_year</code> — извлекает год из поля <code>year</code> (книга) или <code>date</code>
                        (газета/журнал);</li>
                    <li><code>filter_by_year</code> — фильтрация массива по году;</li>
                    <li><code>render_item</code>, <code>render_list</code> — форматирование вывода.</li>
                </ul>
            </li>
            <li>Форма передаёт год через параметр <code>?year=YYYY</code>.</li>
        </ul>
    </details>
</body>

</html>