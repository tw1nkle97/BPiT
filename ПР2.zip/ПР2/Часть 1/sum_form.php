<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

/**
 * Пользовательская функция, возвращающая сумму двух чисел.
 */
function sumTwoNumbers(float $a, float $b): float
{
    return $a + $b;
}

// Обработка формы
$result = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $num1 = $_POST['num1'] ?? null;
    $num2 = $_POST['num2'] ?? null;

    if ($num1 === '' || $num2 === '') {
        $error = 'Введите оба числа!';
    } elseif (!is_numeric($num1) || !is_numeric($num2)) {
        $error = 'Оба значения должны быть числами!';
    } else {
        $result = sumTwoNumbers((float) $num1, (float) $num2);
    }
}
?>
<!doctype html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Сумма двух чисел (Задание 6)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 40px;
        }

        form {
            margin-bottom: 20px;
        }

        input {
            padding: 8px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 8px 16px;
            background: #2d6cdf;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background: #1f57be;
        }

        .result {
            margin-top: 15px;
            font-weight: bold;
        }

        .error {
            color: #c00;
        }
    </style>
</head>

<body>

    <h1>Практическая работа №2 — Задание 6</h1>
    <p>Функция вычисляет сумму двух чисел. Введите значения и нажмите «Посчитать».</p>

    <form method="post" action="">
        <label>Первое число: <input type="text" name="num1"
                value="<?= htmlspecialchars($_POST['num1'] ?? '') ?>"></label><br>
        <label>Второе число: <input type="text" name="num2"
                value="<?= htmlspecialchars($_POST['num2'] ?? '') ?>"></label><br>
        <button type="submit">Посчитать</button>
    </form>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php elseif ($result !== null): ?>
        <p class="result">Сумма чисел: <?= $result ?></p>
    <?php endif; ?>

</body>

</html>