<?php
/*******************************************************
 * Single-file generic CRUD for existing MySQL table
 * Автогенерация форм/SQL по схеме таблицы
 *******************************************************/
declare(strict_types=1);
session_start();

/* ====== НАСТРОЙКИ ПОД ВАШ СЕРВЕР ====== */
$host = 'localhost';   // localhost
$port = 3306;          // как в DBeaver
$db = 'pr3';         // ВАША БД
$user = 'root';        // ВАШ пользователь
$pass = '1234';  // ВАШ пароль
$charset = 'utf8mb4';
$table = 'students';    // ВАША существующая таблица

/* ====== ПОДКЛЮЧЕНИЕ ====== */
try {
    $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    exit('DB connection failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
}

/* ====== ВСПОМОГАТЕЛЬНОЕ ====== */
function h(?string $v): string
{
    return htmlspecialchars($v ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
function csrf_check(): void
{
    if (($_POST['csrf'] ?? '') !== ($_SESSION['csrf'] ?? '')) {
        http_response_code(403);
        exit('CSRF');
    }
}
function flash(?string $msg = null): ?string
{
    if ($msg !== null) {
        $_SESSION['flash'] = $msg;
        return null;
    }
    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}

/* ====== ЧТЕНИЕ СХЕМЫ ТАБЛИЦЫ ====== */
try {
    // Определяем PK
    $pkStmt = $pdo->prepare("
        SELECT kcu.COLUMN_NAME
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
        JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
             ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
            AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
            AND tc.TABLE_NAME = kcu.TABLE_NAME
        WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
          AND tc.TABLE_SCHEMA = ?
          AND tc.TABLE_NAME = ?
        ORDER BY kcu.ORDINAL_POSITION
        LIMIT 1
    ");
    $pkStmt->execute([$db, $table]);
    $pk = $pkStmt->fetchColumn();

    // Все колонки
    $colStmt = $pdo->prepare("
        SELECT COLUMN_NAME, DATA_TYPE, COLUMN_KEY, EXTRA, IS_NULLABLE, COLUMN_DEFAULT
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
        ORDER BY ORDINAL_POSITION
    ");
    $colStmt->execute([$db, $table]);
    $columns = $colStmt->fetchAll();

    if (!$columns) {
        throw new RuntimeException("Table `$table` not found in `$db`.");
    }
    if (!$pk) {
        // если PK не нашли — предполагаем первый столбец как PK
        $pk = $columns[0]['COLUMN_NAME'];
    }

    // Разрешённые к вводу (без автоинкрементного PK)
    $writable = [];
    foreach ($columns as $c) {
        $isAuto = stripos($c['EXTRA'] ?? '', 'auto_increment') !== false;
        if ($c['COLUMN_NAME'] === $pk && $isAuto)
            continue;
        $writable[] = $c;
    }
} catch (Throwable $e) {
    http_response_code(500);
    exit('Schema read error: ' . h($e->getMessage()));
}

/* ====== ДЕЙСТВИЯ ====== */
$action = $_GET['action'] ?? 'list';

/* CREATE */
if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $fields = [];
    $placeholders = [];
    $values = [];
    foreach ($writable as $col) {
        $name = $col['COLUMN_NAME'];
        $val = $_POST[$name] ?? null;
        $val = ($val === '') ? null : $val;
        $fields[] = "`$name`";
        $placeholders[] = '?';
        $values[] = $val;
    }
    if ($fields) {
        $sql = "INSERT INTO `$table` (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        flash('Запись добавлена');
    }
    header('Location: ?');
    exit;
}

/* UPDATE */
if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = $_POST[$pk] ?? null;
    if ($id === null || $id === '') {
        http_response_code(400);
        exit('Bad id');
    }

    $sets = [];
    $values = [];
    foreach ($writable as $col) {
        $name = $col['COLUMN_NAME'];
        if ($name === $pk)
            continue;
        $val = $_POST[$name] ?? null;
        $val = ($val === '') ? null : $val;
        $sets[] = "`$name` = ?";
        $values[] = $val;
    }
    $values[] = $id;

    if ($sets) {
        $sql = "UPDATE `$table` SET " . implode(', ', $sets) . " WHERE `$pk` = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        flash('Изменения сохранены');
    }
    header('Location: ?');
    exit;
}

/* DELETE */
if ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = $_POST['id'] ?? null;
    if ($id !== null && $id !== '') {
        $stmt = $pdo->prepare("DELETE FROM `$table` WHERE `$pk` = ?");
        $stmt->execute([$id]);
        flash("Запись #" . h((string) $id) . " удалена");
    }
    header('Location: ?');
    exit;
}

/* ====== ДАННЫЕ ДЛЯ СПИСКА / РЕДАКТИРОВАНИЯ ====== */
$flash = flash();

if ($action === 'edit') {
    $id = $_GET['id'] ?? null;
    $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE `$pk` = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        $action = 'list';
        $row = null;
    }
} else {
    $row = null;
}

// Получим первые 200 строк для списка
$list = $pdo->query("SELECT * FROM `$table` ORDER BY `$pk` DESC LIMIT 200")->fetchAll();

/* ====== UI ====== */
?>
<!doctype html>
<html lang="ru">
<meta charset="utf-8">
<title>CRUD — <?= h($db) ?>.<?= h($table) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">

<body class="container">
    <header>
        <h1>CRUD: <code><?= h($db) ?></code>.<code><?= h($table) ?></code></h1>
        <p>PK: <code><?= h($pk) ?></code></p>
        <?php if ($flash): ?><mark><?= h($flash) ?></mark><?php endif; ?>
    </header>

    <?php if ($action === 'edit' && $row): ?>
        <article>
            <h3>Правка #<?= h((string) $row[$pk]) ?></h3>
            <form method="post" action="?action=update">
                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
                <input type="hidden" name="<?= $pk ?>" value="<?= h((string) $row[$pk]) ?>">
                <div class="grid">
                    <?php foreach ($columns as $col):
                        $name = $col['COLUMN_NAME'];
                        $isAuto = stripos($col['EXTRA'] ?? '', 'auto_increment') !== false;
                        $val = $row[$name] ?? '';
                        $type = strtolower($col['DATA_TYPE']);
                        $inputType = in_array($type, ['int', 'bigint', 'smallint', 'tinyint', 'mediumint', 'decimal', 'float', 'double']) ? 'number' : (in_array($type, ['date']) ? 'date' : (in_array($type, ['datetime', 'timestamp']) ? 'datetime-local' : 'text'));
                        if ($name === $pk && $isAuto): ?>
                            <label><?= $name ?> (PK, auto)
                                <input value="<?= h((string) $val) ?>" disabled>
                            </label>
                        <?php else: ?>
                            <label><?= $name ?>
                                <?php if (in_array($type, ['text', 'mediumtext', 'longtext'])): ?>
                                    <textarea name="<?= $name ?>" rows="3"><?= h((string) $val) ?></textarea>
                                <?php else: ?>
                                    <input type="<?= $inputType ?>" name="<?= $name ?>"
                                        value="<?= h((string) ($inputType === 'datetime-local' && $val ? str_replace(' ', 'T', substr($val, 0, 19)) : $val)) ?>">
                                <?php endif; ?>
                            </label>
                        <?php endif;
                    endforeach; ?>
                </div>
                <button type="submit">Сохранить</button>
                <a class="secondary" href="?">Отмена</a>
            </form>
        </article>
    <?php endif; ?>

    <article>
        <h3>Добавить запись</h3>
        <form method="post" action="?action=create">
            <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
            <div class="grid">
                <?php foreach ($writable as $col):
                    $name = $col['COLUMN_NAME'];
                    $type = strtolower($col['DATA_TYPE']);
                    $inputType = in_array($type, ['int', 'bigint', 'smallint', 'tinyint', 'mediumint', 'decimal', 'float', 'double']) ? 'number' : (in_array($type, ['date']) ? 'date' : (in_array($type, ['datetime', 'timestamp']) ? 'datetime-local' : 'text')); ?>
                    <label><?= $name ?>
                        <?php if (in_array($type, ['text', 'mediumtext', 'longtext'])): ?>
                            <textarea name="<?= $name ?>" rows="3"></textarea>
                        <?php else: ?>
                            <input type="<?= $inputType ?>" name="<?= $name ?>">
                        <?php endif; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <button type="submit">Добавить</button>
        </form>
    </article>

    <article>
        <h3>Список (первые 200)</h3>
        <table role="grid">
            <thead>
                <tr>
                    <?php foreach ($columns as $c): ?>
                        <th><?= h($c['COLUMN_NAME']) ?></th><?php endforeach; ?>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($list as $r): ?>
                    <tr>
                        <?php foreach ($columns as $c):
                            $name = $c['COLUMN_NAME']; ?>
                            <td><?= h((string) $r[$name]) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <a href="?action=edit&id=<?= h((string) $r[$pk]) ?>">Править</a>
                            <form method="post" action="?action=delete" style="display:inline"
                                onsubmit="return confirm('Удалить запись #<?= h((string) $r[$pk]) ?>?')">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
                                <input type="hidden" name="id" value="<?= h((string) $r[$pk]) ?>">
                                <button class="secondary" style="margin-left:.5rem">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$list): ?>
                    <tr>
                        <td colspan="<?= count($columns) + 1 ?>">Нет данных</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </article>

    <footer><small>PDO • автогенерация по INFORMATION_SCHEMA • безопасные prepared statements</small></footer>
</body>

</html>